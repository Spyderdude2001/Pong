// convpng v7.2
#include <stdint.h>
#include "logo_gfx.h"

uint16_t logo_gfx_pal[2] = {
 0xFFFF,  // 00 :: rgb(255,255,255)
 0x0000,  // 01 :: rgb(0,0,0)
};
