// convpng v7.2
// this file contains all the graphics sources for easy inclusion in a project
#ifndef __logo_gfx__
#define __logo_gfx__
#include <stdint.h>

#define logo_gfx_transparent_color_index 0

#define scoreErase_width 10
#define scoreErase_height 10
#define scoreErase_size 102
extern uint8_t scoreErase_data[102];
#define scoreErase ((gfx_sprite_t*)scoreErase_data)
#define sizeof_logo_gfx_pal 4
extern uint16_t logo_gfx_pal[2];

#endif
