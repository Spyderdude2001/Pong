#include <stdbool.h>
#include <stddef.h>
#include <stdint.h>
#include <tice.h>

#include <math.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include <keypadc.h>
#include <graphx.h>
#include "gfx/logo_gfx.h"

void play();
void mainMenu();
void dispMainMenu();
void ps();
void score();
int setting = 0;

uint8_t p1 = 10;
uint8_t p2 = 10;
uint8_t ballx = 7;
uint8_t bally = 10;
int xballdir = 1;
int yballdir = 1;
uint8_t p1score = 0;
uint8_t p2score = 0;
uint8_t leave = 0;

uint8_t gmode = 1;
uint8_t directionNum = 1;

void main(void) {
    uint8_t pick = 0;
    gfx_Begin();
    gfx_SetPalette(logo_gfx_pal, sizeof_logo_gfx_pal, 0);
    dispMainMenu();
    mainMenu();
    gfx_End();
    os_ClrHome();

}

void mainMenu(){
    uint8_t leave = 0;
    while(leave==0){
        kb_Scan();
        if (kb_Data[6] == kb_Clear)
            leave=1;
        if (kb_Data[6] == kb_Enter)
                play();
        }
    }

void play(){

    gfx_FillScreen(9);
    gfx_Sprite(scoreErase,0,0);
    ps(p1score,0,0);
    gfx_Sprite(scoreErase,330,0);
    ps(p2score,330,0);

    do{
        gfx_SetColor(gfx_white);
        gfx_FillRectangle(ballx, bally, 4, 4);
        gfx_FillRectangle(0,p1,5,20);
        gfx_FillRectangle(316,p2,5,20);

        delay(50);

        if (ballx <= 6){
            if (bally-3>=p1&&bally+3<=p1+19)
                yballdir = floor((p1-bally-8)/2);
                ballx = 6;
            xballdir = 1;
        }else{
        score();
        }
        if (ballx >= 312){
            if (bally-3>=p2&&bally+3<=p2+19)
                yballdir = floor((p2-bally-8)/2);
                ballx = 312;
            xballdir = -1;
        }else{

        score();

        }

        if (bally<11 || bally>236)
            yballdir = -yballdir;

        ballx+=xballdir;
        bally+=yballdir;

        gfx_SetColor(gfx_black);

        kb_Scan();
        if (kb_Data[3] == kb_7){
            gfx_FillRectangle(0,p1,5,20);
            p1-=5;
        }
        if (kb_Data[3] == kb_1){
            gfx_FillRectangle(0,p1,5,20);
            p1+=5;
        }
        if (kb_Data[5] == kb_3){
            gfx_FillRectangle(316,p2,5,20);
            p2+=5;
        }
        if (kb_Data[5] == kb_9){
            gfx_FillRectangle(316,p2,5,20);
            p2-=5;
        }
        if (kb_Data[6] == kb_Clear){
            leave = 1;
        }

        if (p1<10)
            p1=10;
        if (p1>221)
            p1 = 221;
        if (p2<10);
            p2=10;
        if (p2>221)
            p2 = 221;


    }while(p1score<7 && p2score<7 || leave == 1);

    ps("Press [CLEAR] for Main Menu",80,120);
    ps("Press [ENTER] to Play Again",60,130);
    delay(5000);
}

void dispMainMenu(){
    gfx_FillScreen(8);
    ps("PONG",125,100);
    ps("--------------",100,110);
    ps("Press [CLEAR] to Exit",80,130);
    ps("Press [ENTER] to Play",80,120);
    ps("Press [MODE] for controls",75,140);
}

void ps(char *inputString, int8_t xValue, int8_t yValue){
    gfx_PrintStringXY(inputString,xValue,yValue);
}

void score(){
    uint8_t leave = 0;
    if (ballx==6){
        gfx_Sprite(scoreErase,0,0);
        ps(p1score,0,0);
    }
    if (ballx==312){
        gfx_Sprite(scoreErase,330,0);
        ps(p2score,330,0);
    }
    while(leave == 0){
        kb_Scan();
        if (kb_Data[6] == kb_Enter)
            leave = 1;
    }
    gfx_SetColor (gfx_black);
    gfx_FillRectangle (ballx, bally, 4, 4);

}
